// Создаем новый объект XMLHttpRequest
var xhr = new XMLHttpRequest();

// Открываем соединение с XML-файлом
xhr.open("GET", "table.xml", true);

// Устанавливаем заголовок для указания типа данных
xhr.setRequestHeader('Content-Type', 'text/xml');

// Отправляем запрос на сервер для получения XML-данных
xhr.send();

// Обработка ответа от сервера
xhr.onreadystatechange = function() {
    if (xhr.readyState === 4 && xhr.status === 200) {
        var xmlDoc = xhr.responseXML;

        // Получаем все элементы <reservation>
        var reservations = xmlDoc.getElementsByTagName("reservation");

        // Проходим по каждому элементу <reservation> и выводим данные
        for (var i = 0; i < reservations.length; i++) {
            var name = reservations[i].getElementsByTagName("name")[0].childNodes[0].nodeValue;
            var phone = reservations[i].getElementsByTagName("phone")[0].childNodes[0].nodeValue;
            var date = reservations[i].getElementsByTagName("date")[0].childNodes[0].nodeValue;
            var time = reservations[i].getElementsByTagName("time")[0].childNodes[0].nodeValue;
            var people = reservations[i].getElementsByTagName("people")[0].childNodes[0].nodeValue;
            var comments = reservations[i].getElementsByTagName("comments")[0].childNodes[0].nodeValue;

            // Выводим данные в консоль
            console.log("Name: " + name);
            console.log("Phone: " + phone);
            console.log("Date: " + date);
            console.log("Time: " + time);
            console.log("Number of People: " + people);
            console.log("Comments: " + comments);
        }
    }
};